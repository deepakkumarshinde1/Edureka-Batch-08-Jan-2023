// import (optional)

import Counter from "./Counter";

// component code
const App = () => {
  return (
    <>
      <center>
        <Counter start="1" />
        <Counter start="10" />
        <Counter start="20" />
        <Counter start="30" />
      </center>
    </>
  );
};

// export
export default App;
