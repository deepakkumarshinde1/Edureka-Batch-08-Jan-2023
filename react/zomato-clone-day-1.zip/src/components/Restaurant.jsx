const Restaurant = () => {
  return (
    <>
      <h1>Restaurant</h1>
    </>
  );
};

export default Restaurant;
