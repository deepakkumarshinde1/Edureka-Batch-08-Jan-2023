// import (optional)

import Counter from "./Counter";

// component code
const App = () => {
  return (
    <>
      <center>
        <Counter />
      </center>
    </>
  );
};

// export
export default App;
