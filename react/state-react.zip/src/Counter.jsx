import React from "react";

// function  don't state
const Counter = () => {
  let [count, setCount] = React.useState(100); // [value,updateValueFunction]
  let [text, setText] = React.useState("Edureka");

  let incCount = () => {
    count++;
    setCount(count); // update state
  };
  let decCount = () => {
    count--;
    setCount(count); // update state
  };

  let changeText = () => {
    setText("Its Awesome");
  };
  return (
    <>
      <center>
        <h1>Count {count}</h1>
        <button onClick={incCount}>Inc</button>
        <button onClick={decCount}>Dec</button>
        <h1>{text}</h1>
        <button onClick={changeText}>Change Text</button>
      </center>
    </>
  );
};

export default Counter;
